# BioSim_G09_Michael_Daniel
Modelling the Ecosystem of Rossumøya
